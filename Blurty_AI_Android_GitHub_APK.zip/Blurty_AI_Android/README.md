# Blurty AI Android v5

Aplikacja do nauki metodą Blurting Method. Działa jako natywna aplikacja Android z interfejsem WebView.

## Najważniejsze funkcje v5
- Blurting z lokalną oceną semantyczną
- Internet AI: Wikipedia/Wikidata + oznaczenie pewności
- inteligentne fiszki i powtórki SRS
- Quiz, Egzamin i Boss Fight
- OCR zdjęć notatek (Tesseract.js)
- odpowiedzi głosowe przez system Android
- Terminarz z powiadomieniami i wyborem liczby dni wcześniej
- widget Android
- XP, monety, sklep, ochrona streaka, osiągnięcia
- mapa wiedzy i tryb „Naucz mnie do 100%”
- konto/registracja e-mail i synchronizacja przez Firebase po jednorazowej konfiguracji
- tryb gościa i ręczny eksport/import kopii danych

## Build
`gradle assembleDebug`

Debug APK jest podpisywany dołączonym stałym kluczem deweloperskim, aby kolejne testowe buildy v5+ można było instalować jako aktualizacje. Tego klucza nie należy używać do publikacji produkcyjnej w Google Play.

Konfiguracja chmury: zobacz `FIREBASE_SETUP.md`.
