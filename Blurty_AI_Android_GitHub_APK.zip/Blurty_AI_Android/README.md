# Blurty AI — Android

Pełnoekranowa aplikacja Android opakowująca Blurty AI Local w natywny WebView.

## Co działa
- pełny ekran bez paska Chrome
- Blurting, timery, historia, XP, quizy i fiszki
- lokalny zapis danych
- wybieranie plików i zdjęć z telefonu
- lokalny model AI bez klucza API (model pobiera się z internetu przy pierwszym użyciu)

## Najłatwiejszy build APK — GitHub Actions
1. Utwórz nowe repozytorium na GitHubie.
2. Wgraj zawartość tego folderu do repozytorium.
3. Wejdź w zakładkę **Actions**.
4. Otwórz **Build Blurty AI APK** i uruchom workflow.
5. Po zakończeniu pobierz artifact **Blurty-AI-APK**.
6. W ZIP-ie z artifactem znajdziesz `app-debug.apk`.

Na Androidzie może być potrzebne zezwolenie na instalowanie aplikacji z nieznanych źródeł dla przeglądarki lub menedżera plików.


## Quiz i fiszki v2
- poprawione pytania Prawda/Fałsz (w tym rzeczywiście fałszywe zdania)
- naturalniejsze pytania z definicji, osób i dat
- fiszki z konkretnymi pytaniami zamiast losowych, urwanych poleceń
- ocena fiszki dopiero po odsłonięciu odpowiedzi
