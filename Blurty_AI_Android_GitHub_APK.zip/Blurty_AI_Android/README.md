# Blurty AI v4 — Android

Pełnoekranowa aplikacja Android do nauki metodą Blurting Method.

## Nowości v4
- nowe, nowocześniejsze lobby
- płynne animacje, efekty kart, ładowania i wyników
- Internet AI bez klucza API
- dodatkowe fakty z Wikipedii i Wikidanych
- widoczne źródła internetowe przy materiałach i wynikach
- mądrzejsze fiszki i quizy łączące notatki z wybranymi faktami online
- lokalny model semantyczny nadal sprawdza odpowiedzi własnymi słowami
- jeśli nie ma internetu, aplikacja automatycznie wraca do notatek

## Prywatność i sieć
Aplikacja nie wymaga konta API. Internet jest używany do pobrania lokalnego modelu AI oraz do odczytu publicznych danych Wikimedia. Dane nauki są zapisywane lokalnie na urządzeniu.

## Build APK przez GitHub Actions
1. Wgraj paczkę projektu do repozytorium zgodnie z istniejącym workflow.
2. Wejdź w **Actions**.
3. Poczekaj na zielony build **Build Blurty AI APK**.
4. Pobierz artifact **Blurty-AI-APK**.
5. Rozpakuj ZIP i zainstaluj `app-debug.apk`.
