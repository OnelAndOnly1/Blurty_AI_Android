# Blurty AI Android v5.1 — wygląd jak normalna aplikacja Android

Ta wersja jest przygotowana do instalacji testowej poza Google Play, ale po instalacji zachowuje się jak zwykła aplikacja:

- brak paska Chrome / adresu,
- normalny ekran startowy (splash),
- normalny pasek stanu i nawigacji Androida,
- nazwa i ikona Blurty AI w launcherze i ostatnich aplikacjach,
- brak dopisku `-debug` w numerze wersji,
- WebView nie jest oznaczony jako debuggable,
- zachowany dotychczasowy identyfikator testowej aplikacji, więc kolejne buildy mogą aktualizować v5 bez utraty lokalnych danych.

## Ważne

Android nadal wie, skąd aplikacja została zainstalowana. APK instalowany ręcznie może pokazać komunikat o „nieznanym źródle”. Tego nie da się uczciwie usunąć bez instalacji przez Google Play lub inny zaufany sklep.

Klucz w paczce jest wyłącznie kluczem testowym. Nie używaj go do przyszłej produkcyjnej publikacji w Google Play.


## Blurty AI v6
- Bez logowania i rejestracji.
- Osiągnięcia, monety i streak dostępne lokalnie.
- Ręczny eksport/import kopii postępu w Ustawieniach.
- Materiały i terminarz obsługują osobne przedmioty (Historia, Biologia, Chemia itd.).
