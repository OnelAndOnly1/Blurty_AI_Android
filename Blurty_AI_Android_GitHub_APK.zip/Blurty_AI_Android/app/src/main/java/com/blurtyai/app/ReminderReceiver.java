package com.blurtyai.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String title=i.getStringExtra("title"), text=i.getStringExtra("text"), id=i.getStringExtra("id");
        Intent open=new Intent(c,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,(id==null?0:id.hashCode()),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT>=26 ? new Notification.Builder(c,ReminderScheduler.CHANNEL_ID) : new Notification.Builder(c);
        b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title==null?"Blurty AI":title).setContentText(text==null?"Czas na naukę":text).setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH);
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id==null?1001:id.hashCode(),b.build());
    }
}
