package com.blurtyai.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class BlurtyWidgetProvider extends AppWidgetProvider {
    private static final String PREF="blurty_widget";
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids){String text=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("text","Czas na krótką powtórkę 🧠");for(int id:ids)update(c,m,id,text);}
    static void update(Context c,AppWidgetManager m,int id,String text){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_blurty);v.setTextViewText(R.id.widgetText,text);Intent i=new Intent(c,MainActivity.class);PendingIntent p=PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(R.id.widgetRoot,p);m.updateAppWidget(id,v);}
    public static void updateAll(Context c,String text){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("text",text).apply();AppWidgetManager m=AppWidgetManager.getInstance(c);ComponentName n=new ComponentName(c,BlurtyWidgetProvider.class);int[] ids=m.getAppWidgetIds(n);for(int id:ids)update(c,m,id,text);}
}
