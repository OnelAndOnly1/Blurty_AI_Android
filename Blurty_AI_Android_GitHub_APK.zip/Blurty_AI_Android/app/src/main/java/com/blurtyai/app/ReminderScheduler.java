package com.blurtyai.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.Map;

public final class ReminderScheduler {
    public static final String CHANNEL_ID = "blurty_study_reminders";
    private static final String PREFS = "blurty_native_reminders";
    private static PendingIntent pending(Context c, String id, String title, String text) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("id", id); i.putExtra("title", title); i.putExtra("text", text);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context c, String id, long at, String title, String text) {
        if (at <= System.currentTimeMillis()) return;
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(c,id,title,text));
        try {
            JSONObject o=new JSONObject();o.put("at",at);o.put("title",title);o.put("text",text);
            c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString("a_"+id,o.toString()).apply();
        } catch(Exception ignored) {}
    }
    public static void cancel(Context c, String id) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pending(c,id,"",""));
        c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().remove("a_"+id).apply();
    }
    public static void rescheduleAll(Context c) {
        SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        for(Map.Entry<String,?> e:p.getAll().entrySet()) {
            if(!e.getKey().startsWith("a_") || !(e.getValue() instanceof String)) continue;
            try { JSONObject o=new JSONObject((String)e.getValue()); long at=o.getLong("at"); if(at>System.currentTimeMillis()) schedule(c,e.getKey().substring(2),at,o.optString("title","Blurty AI"),o.optString("text","Czas na naukę")); } catch(Exception ignored) {}
        }
    }
}
