/* Blurty Cloud — Firebase Email/Password + Firestore REST sync.
   Requires a Firebase project configured once in Settings. No secret is stored here. */
(() => {
  'use strict';
  const K='blurty:cloud';
  const C='blurty:firebase';
  const read=(k,f={})=>{try{return JSON.parse(localStorage.getItem(k)||'null')||f}catch{return f}};
  const write=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
  let session=read(K,{mode:'guest'});
  let config=read(C,{apiKey:'',projectId:''});
  const emit=()=>window.dispatchEvent(new CustomEvent('blurty-cloud-status',{detail:status()}));
  function configured(){return !!(config.apiKey&&config.projectId)}
  function status(){return {configured:configured(),loggedIn:!!session.idToken,mode:session.idToken?'account':'guest',email:session.email||'',uid:session.localId||'',projectId:config.projectId||''}}
  function configure(c){config={apiKey:(c.apiKey||'').trim(),projectId:(c.projectId||'').trim()};write(C,config);emit();return status()}
  async function jfetch(url,opts={}){
    const r=await fetch(url,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});
    let j={};try{j=await r.json()}catch{}
    if(!r.ok){const msg=j?.error?.message||`HTTP ${r.status}`;throw new Error(msg)}
    return j;
  }
  async function authCall(kind,email,password){
    if(!configured())throw new Error('Najpierw skonfiguruj synchronizację Firebase');
    const endpoint=kind==='register'?'accounts:signUp':'accounts:signInWithPassword';
    const j=await jfetch(`https://identitytoolkit.googleapis.com/v1/${endpoint}?key=${encodeURIComponent(config.apiKey)}`,{method:'POST',body:JSON.stringify({email,password,returnSecureToken:true})});
    session={mode:'account',email:j.email||email,localId:j.localId,idToken:j.idToken,refreshToken:j.refreshToken,expiresAt:Date.now()+(+j.expiresIn||3600)*1000-60000};
    write(K,session);emit();return status();
  }
  const register=(email,password)=>authCall('register',email,password);
  const login=(email,password)=>authCall('login',email,password);
  function logout(){session={mode:'guest'};write(K,session);emit()}
  async function ensureToken(){
    if(!session.idToken)throw new Error('Zaloguj się');
    if(Date.now()<(session.expiresAt||0))return session.idToken;
    if(!session.refreshToken)throw new Error('Sesja wygasła — zaloguj się ponownie');
    const body=new URLSearchParams({grant_type:'refresh_token',refresh_token:session.refreshToken});
    const r=await fetch(`https://securetoken.googleapis.com/v1/token?key=${encodeURIComponent(config.apiKey)}`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
    const j=await r.json();if(!r.ok)throw new Error(j?.error?.message||'Nie udało się odświeżyć sesji');
    session.idToken=j.id_token;session.refreshToken=j.refresh_token||session.refreshToken;session.localId=j.user_id||session.localId;session.expiresAt=Date.now()+(+j.expires_in||3600)*1000-60000;write(K,session);emit();return session.idToken;
  }
  function docUrl(){return `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(config.projectId)}/databases/(default)/documents/users/${encodeURIComponent(session.localId)}`}
  async function push(payload){
    const token=await ensureToken();
    const body={fields:{payload:{stringValue:JSON.stringify(payload)},email:{stringValue:session.email||''},updatedAt:{timestampValue:new Date().toISOString()}}};
    await jfetch(docUrl(),{method:'PATCH',headers:{Authorization:`Bearer ${token}`},body:JSON.stringify(body)});
    return true;
  }
  async function pull(){
    const token=await ensureToken();
    const r=await fetch(docUrl(),{headers:{Authorization:`Bearer ${token}`}});
    if(r.status===404)return null;
    const j=await r.json();if(!r.ok)throw new Error(j?.error?.message||'Nie udało się pobrać danych');
    const raw=j?.fields?.payload?.stringValue;if(!raw)return null;
    try{return JSON.parse(raw)}catch{return null}
  }
  window.BlurtyCloud={status,configure,register,login,logout,push,pull};
  setTimeout(emit,0);
})();
