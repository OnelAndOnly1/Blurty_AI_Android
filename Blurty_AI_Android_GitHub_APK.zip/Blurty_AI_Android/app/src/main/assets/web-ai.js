/* Blurty AI Web — internet grounding without an API key. Uses Wikimedia APIs. */
(() => {
  'use strict';

  const WIKI='https://pl.wikipedia.org/w/api.php';
  const WIKIDATA='https://www.wikidata.org/w/api.php';
  const state={phase:'idle',online:navigator.onLine,lastQuery:'',sources:[],error:'',updatedAt:0};
  const CACHE_PREFIX='blurty:web:';
  const TTL=6*60*60*1000;

  const norm=s=>(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9ąćęłńóśźż\s-]/gi,' ').replace(/\s+/g,' ').trim();
  const emit=(patch={})=>{Object.assign(state,patch);window.dispatchEvent(new CustomEvent('blurty-web-ai-status',{detail:{...state}}));};
  const sentenceSplit=text=>(text||'').replace(/\s+/g,' ').split(/(?<=[.!?])\s+/).map(s=>s.trim()).filter(s=>s.length>=28&&s.length<=340);
  const tokens=s=>norm(s).split(' ').filter(w=>w.length>3);

  function similarity(a,b){
    const A=new Set(tokens(a)),B=new Set(tokens(b));
    if(!A.size||!B.size)return 0;
    let inter=0;A.forEach(x=>B.has(x)&&inter++);
    return inter/Math.max(A.size,B.size);
  }
  function cleanQuery(title,notes=''){
    let q=(title||'').trim();
    if(!q){
      const freq={};tokens(notes).forEach(w=>freq[w]=(freq[w]||0)+1);
      q=Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,5).map(x=>x[0]).join(' ');
    }
    return q.replace(/[<>\[\]{}|]/g,' ').replace(/\s+/g,' ').trim().slice(0,120);
  }
  function readCache(query){
    try{
      const v=JSON.parse(localStorage.getItem(CACHE_PREFIX+norm(query))||'null');
      if(v&&Date.now()-v.saved<TTL)return v.data;
    }catch{}
    return null;
  }
  function writeCache(query,data){
    try{localStorage.setItem(CACHE_PREFIX+norm(query),JSON.stringify({saved:Date.now(),data}))}catch{}
  }

  async function fetchJSON(url,timeout=8000){
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),timeout);
    try{
      const r=await fetch(url,{signal:controller.signal,headers:{'Accept':'application/json'}});
      if(!r.ok)throw new Error('HTTP '+r.status);
      return await r.json();
    }finally{clearTimeout(timer)}
  }

  async function wikipedia(query){
    const p=new URLSearchParams({
      action:'query',format:'json',origin:'*',generator:'search',gsrsearch:query,gsrlimit:'4',
      prop:'extracts|info',explaintext:'1',exintro:'0',exsentences:'10',inprop:'url',redirects:'1'
    });
    const j=await fetchJSON(`${WIKI}?${p}`);
    const pages=Object.values(j?.query?.pages||{}).sort((a,b)=>(a.index||999)-(b.index||999));
    return pages.map(p=>({title:p.title,url:p.fullurl||`https://pl.wikipedia.org/wiki/${encodeURIComponent(String(p.title||'').replace(/ /g,'_'))}`,extract:p.extract||''})).filter(p=>p.extract);
  }

  async function wikidata(query){
    const p=new URLSearchParams({action:'wbsearchentities',format:'json',origin:'*',language:'pl',uselang:'pl',search:query,limit:'5'});
    const j=await fetchJSON(`${WIKIDATA}?${p}`);
    return (j.search||[]).filter(x=>x.label&&x.description).map(x=>({
      title:x.label,
      url:x.concepturi||`https://www.wikidata.org/wiki/${x.id}`,
      description:x.description
    }));
  }

  function buildFacts(pages,entities,notes=''){
    const out=[];
    const seen=[];
    const push=(text,source,url,type)=>{
      text=(text||'').replace(/\[[^\]]+\]/g,'').replace(/\s+/g,' ').trim();
      if(text.length<28||text.length>340)return;
      if(/może oznaczać|strona ujednoznaczniająca|zobacz też/i.test(text))return;
      if(seen.some(s=>similarity(s,text)>.72))return;
      if(notes&&similarity(notes,text)>.82)return;
      seen.push(text);out.push({text,source,url,type});
    };
    pages.forEach(p=>sentenceSplit(p.extract).slice(0,7).forEach(s=>push(s,`Wikipedia: ${p.title}`,p.url,'wikipedia')));
    entities.forEach(e=>push(`${e.title} — ${e.description}.`,`Wikidata: ${e.title}`,e.url,'wikidata'));
    return out.slice(0,18);
  }

  async function enrich(title,notes=''){
    const query=cleanQuery(title,notes);
    if(!query)throw new Error('Brak tematu do wyszukania');
    const cached=readCache(query);
    if(cached){emit({phase:'ready',online:navigator.onLine,lastQuery:query,sources:cached.sources||[],error:'',updatedAt:Date.now()});return {...cached,cached:true}}
    if(!navigator.onLine){emit({phase:'offline',online:false,error:'Brak internetu',lastQuery:query});throw new Error('Brak internetu')}
    emit({phase:'searching',online:true,lastQuery:query,error:''});
    try{
      const [pages,entities]=await Promise.all([
        wikipedia(query),
        wikidata(query).catch(()=>[])
      ]);
      const sources=[...pages.map(p=>({title:p.title,url:p.url,type:'Wikipedia'})),...entities.slice(0,2).map(e=>({title:e.title,url:e.url,type:'Wikidata'}))];
      const facts=buildFacts(pages,entities,notes);
      if(!facts.length)throw new Error('Nie znaleziono użytecznych informacji');
      const data={query,facts,sources,provider:'Wikimedia'};
      writeCache(query,data);
      emit({phase:'ready',online:true,lastQuery:query,sources,error:'',updatedAt:Date.now()});
      return data;
    }catch(err){
      emit({phase:'error',online:navigator.onLine,lastQuery:query,error:err?.message||'Błąd źródeł internetowych'});
      throw err;
    }
  }

  async function test(){return enrich('II wojna światowa','')}
  window.addEventListener('online',()=>emit({online:true,phase:state.phase==='offline'?'idle':state.phase,error:''}));
  window.addEventListener('offline',()=>emit({online:false,phase:'offline',error:'Brak internetu'}));
  window.BlurtyWebAI={status:()=>({...state}),enrich,test};
})();
