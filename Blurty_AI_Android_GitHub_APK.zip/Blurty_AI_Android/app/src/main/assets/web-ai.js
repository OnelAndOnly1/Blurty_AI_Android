/* Blurty AI Web — grounded internet facts without an API key.
   Uses Polish Wikipedia + Wikidata, compares several returned pages and reports confidence. */
(() => {
  'use strict';
  const WIKI='https://pl.wikipedia.org/w/api.php';
  const WIKIDATA='https://www.wikidata.org/w/api.php';
  const state={phase:'idle',online:navigator.onLine,lastQuery:'',sources:[],error:'',updatedAt:0};
  const CACHE_PREFIX='blurty:web:v2:'; const TTL=6*60*60*1000;
  const norm=s=>(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9ąćęłńóśźż\s-]/gi,' ').replace(/\s+/g,' ').trim();
  const emit=(patch={})=>{Object.assign(state,patch);window.dispatchEvent(new CustomEvent('blurty-web-ai-status',{detail:{...state}}));};
  const sentences=t=>(t||'').replace(/\s+/g,' ').split(/(?<=[.!?])\s+/).map(x=>x.trim()).filter(x=>x.length>=30&&x.length<=360);
  const tokens=s=>norm(s).split(' ').filter(w=>w.length>3);
  function sim(a,b){const A=new Set(tokens(a)),B=new Set(tokens(b));if(!A.size||!B.size)return 0;let n=0;A.forEach(x=>B.has(x)&&n++);return n/Math.max(A.size,B.size)}
  function cleanQuery(title,notes=''){let q=(title||'').trim();if(!q){const f={};tokens(notes).forEach(w=>f[w]=(f[w]||0)+1);q=Object.entries(f).sort((a,b)=>b[1]-a[1]).slice(0,5).map(x=>x[0]).join(' ')}return q.replace(/[<>\[\]{}|]/g,' ').replace(/\s+/g,' ').trim().slice(0,120)}
  async function fetchJSON(url,timeout=9000){const c=new AbortController(),t=setTimeout(()=>c.abort(),timeout);try{const r=await fetch(url,{signal:c.signal,headers:{Accept:'application/json'}});if(!r.ok)throw new Error('HTTP '+r.status);return await r.json()}finally{clearTimeout(t)}}
  function cacheGet(q){try{const x=JSON.parse(localStorage.getItem(CACHE_PREFIX+norm(q))||'null');if(x&&Date.now()-x.at<TTL)return x.data}catch{}return null}
  function cacheSet(q,d){try{localStorage.setItem(CACHE_PREFIX+norm(q),JSON.stringify({at:Date.now(),data:d}))}catch{}}
  async function wikipedia(query){const p=new URLSearchParams({action:'query',format:'json',origin:'*',generator:'search',gsrsearch:query,gsrlimit:'6',prop:'extracts|info',explaintext:'1',exintro:'0',exsentences:'12',inprop:'url',redirects:'1'});const j=await fetchJSON(`${WIKI}?${p}`);return Object.values(j?.query?.pages||{}).sort((a,b)=>(a.index||999)-(b.index||999)).map(p=>({title:p.title,url:p.fullurl||`https://pl.wikipedia.org/wiki/${encodeURIComponent(String(p.title||'').replace(/ /g,'_'))}`,extract:p.extract||''})).filter(x=>x.extract)}
  async function wikidata(query){const p=new URLSearchParams({action:'wbsearchentities',format:'json',origin:'*',language:'pl',uselang:'pl',search:query,limit:'6'});const j=await fetchJSON(`${WIKIDATA}?${p}`);return (j.search||[]).filter(x=>x.label&&x.description).map(x=>({title:x.label,url:x.concepturi||`https://www.wikidata.org/wiki/${x.id}`,description:x.description}))}
  function buildFacts(pages,entities,notes=''){
    const raw=[];pages.forEach((p,pi)=>sentences(p.extract).slice(0,9).forEach(text=>raw.push({text,source:`Wikipedia: ${p.title}`,url:p.url,page:pi,type:'wikipedia'})));
    const out=[];
    for(const item of raw){let text=item.text.replace(/\[[^\]]+\]/g,'').replace(/\s+/g,' ').trim();if(/może oznaczać|strona ujednoznaczniająca|zobacz też/i.test(text))continue;if(notes&&sim(notes,text)>.86)continue;if(out.some(x=>sim(x.text,text)>.72))continue;
      let support=1;const supportSources=[item.source];for(const other of raw){if(other.page===item.page)continue;if(sim(text,other.text)>.34){support++;if(!supportSources.includes(other.source))supportSources.push(other.source)}if(support>=3)break}
      const confidence=support>=3?'wysoka':support>=2?'średnia':'podstawowa';out.push({...item,text,support,confidence,supportSources});if(out.length>=18)break;
    }
    for(const e of entities){const text=`${e.title} — ${e.description}.`;if(out.some(x=>sim(x.text,text)>.68))continue;out.push({text,source:`Wikidata: ${e.title}`,url:e.url,type:'wikidata',support:1,confidence:'podstawowa',supportSources:[`Wikidata: ${e.title}`]});if(out.length>=20)break}
    return out;
  }
  async function enrich(title,notes=''){
    const query=cleanQuery(title,notes);if(!query)throw new Error('Brak tematu do wyszukania');const c=cacheGet(query);if(c){emit({phase:'ready',online:navigator.onLine,lastQuery:query,sources:c.sources||[],error:'',updatedAt:Date.now()});return {...c,cached:true}}
    if(!navigator.onLine){emit({phase:'offline',online:false,error:'Brak internetu',lastQuery:query});throw new Error('Brak internetu')}
    emit({phase:'searching',online:true,lastQuery:query,error:''});
    try{const [pages,entities]=await Promise.all([wikipedia(query),wikidata(query).catch(()=>[])]);const sources=[...pages.map(p=>({title:p.title,url:p.url,type:'Wikipedia'})),...entities.slice(0,3).map(e=>({title:e.title,url:e.url,type:'Wikidata'}))];const facts=buildFacts(pages,entities,notes);if(!facts.length)throw new Error('Nie znaleziono użytecznych informacji');const data={query,facts,sources,provider:'Wikimedia',sourceCount:sources.length};cacheSet(query,data);emit({phase:'ready',online:true,lastQuery:query,sources,error:'',updatedAt:Date.now()});return data}catch(err){emit({phase:'error',online:navigator.onLine,lastQuery:query,error:err?.message||'Błąd źródeł internetowych'});throw err}
  }
  async function test(){return enrich('II wojna światowa','')}
  window.addEventListener('online',()=>emit({online:true,phase:state.phase==='offline'?'idle':state.phase,error:''}));window.addEventListener('offline',()=>emit({online:false,phase:'offline',error:'Brak internetu'}));
  window.BlurtyWebAI={status:()=>({...state}),enrich,test};
})();
