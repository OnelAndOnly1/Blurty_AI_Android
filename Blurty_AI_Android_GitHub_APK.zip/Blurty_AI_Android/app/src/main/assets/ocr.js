/* Blurty OCR — optional local-in-browser OCR using Tesseract.js. */
(() => {
  'use strict';
  let loading=null;
  function loadScript(){
    if(window.Tesseract) return Promise.resolve(window.Tesseract);
    if(loading) return loading;
    loading=new Promise((resolve,reject)=>{
      const s=document.createElement('script');
      s.src='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
      s.async=true;
      s.onload=()=>window.Tesseract?resolve(window.Tesseract):reject(new Error('Tesseract niedostępny'));
      s.onerror=()=>reject(new Error('Nie udało się pobrać OCR'));
      document.head.appendChild(s);
    });
    return loading;
  }
  async function recognize(file,onProgress=()=>{}){
    const T=await loadScript();
    const result=await T.recognize(file,'pol+eng',{logger:m=>{
      if(m.status==='recognizing text')onProgress(Math.round((m.progress||0)*100));
    }});
    return (result?.data?.text||'').replace(/\n{3,}/g,'\n\n').trim();
  }
  window.BlurtyOCR={recognize};
})();
