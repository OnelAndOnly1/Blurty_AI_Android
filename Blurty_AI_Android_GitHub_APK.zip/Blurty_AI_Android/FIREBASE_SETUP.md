# Blurty AI — konfiguracja logowania e-mail i chmury

Funkcja konta jest gotowa w aplikacji, ale potrzebuje własnego projektu Firebase. Dzięki temu postęp może wrócić po odinstalowaniu aplikacji lub zmianie telefonu.

1. Utwórz projekt w Firebase Console.
2. Authentication → Sign-in method → włącz **Email/Password**.
3. Firestore Database → utwórz bazę.
4. Project settings → General → dodaj Web app i skopiuj:
   - `apiKey`
   - `projectId`
5. W Blurty AI: **Konto → Skonfiguruj chmurę** i wklej te dwie wartości.
6. Ustaw reguły Firestore tak, aby użytkownik miał dostęp tylko do swojego dokumentu:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

Web API Key Firebase nie jest hasłem. Bezpieczeństwo danych zapewniają Authentication i reguły Firestore. Nie publikuj haseł użytkowników ani kluczy serwisowych/admin SDK.
